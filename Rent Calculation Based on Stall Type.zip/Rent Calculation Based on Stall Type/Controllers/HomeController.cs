﻿using Microsoft.AspNetCore.Mvc;
using Rent_Calculation_Based_on_Stall_Type.Models;
using System.Diagnostics;
using System.Globalization;

namespace Rent_Calculation_Based_on_Stall_Type.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Calculate(IFormCollection f)
        {

            ViewBag.StallName = f["stallName"];
            ViewBag.StallDet = f["stallDetail"];
            ViewBag.Owner = f["ownerName"];
            ViewBag.Cost = f["costPerDay"];
            ViewBag.Stall = f["stallType"];

            ViewBag.Day = f["noOfDays"];

            int day = Convert.ToInt32(f["noOfDays"]);

            double cost = Convert.ToDouble(f["costPerDay"]);

            double total=0;

            if(f["stallType"]=="Stall")
            {
                total = day * cost;
            }

            else if(f["stallType"]== "GoldStall")
            {
                total = (day * cost) - ((day * cost) * 0.025);
            }


            else if (f["stallType"] == "PlatinumStall")
            {
                total = (day * cost) - ((day * cost) * 0.025);
            }


            ViewBag.Total = total;


            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}